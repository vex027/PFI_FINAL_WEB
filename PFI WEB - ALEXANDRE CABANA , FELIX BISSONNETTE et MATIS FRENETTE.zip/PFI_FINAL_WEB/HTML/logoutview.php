<div class='container'>
    <h2>Successful logout!</h2>
</div>
